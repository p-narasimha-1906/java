package com.parthu.utils;

public class AppExceptionHandler {

}
